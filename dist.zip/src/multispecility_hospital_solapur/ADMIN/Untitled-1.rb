   
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  1
 , 'hemnat'
 , 'shivaputra'
 , 'wakade'
 , '10'
 , 'SELECT'
 , '2000-02-05'
 , 'NO'
 , 'userphoto'
 , 'username'
 , 'password'
 , 'speclilizaion'
 , 'eduauoo'
 , 'job'
 , '2022-04-14'
 , 'lknown'
 , 'document'
 , 'email'
 , '2000-02-05'
 , 1326547897
 , 123549853
 , 23165465
 , pan123465
 , address
 , city
 , distric
 , state
 , country
 , 413218
 , '25-04-2022'
 , '10:59:15 AM')