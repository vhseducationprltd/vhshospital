/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multispecility_hospital_solapur.DATA_TABLES;

import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.table.DefaultTableModel;
import multispecility_hospital_solapur.use.GetConnection;

/**
 *
 * @author heman
 */
public class DATAGET {
    
    //   
    
         
        
    
}
